import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pembayaran',
  templateUrl: './pembayaran.component.html',
  styleUrls: ['./pembayaran.component.scss']
})
export class PembayaranComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
