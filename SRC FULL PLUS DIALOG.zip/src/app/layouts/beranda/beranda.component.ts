import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beranda',
  templateUrl: './beranda.component.html',
  styleUrls: ['./beranda.component.scss']
})
export class BerandaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
