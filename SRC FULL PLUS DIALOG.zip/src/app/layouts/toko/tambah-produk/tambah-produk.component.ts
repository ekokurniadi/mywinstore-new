import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tambah-produk',
  templateUrl: './tambah-produk.component.html',
  styleUrls: ['./tambah-produk.component.scss']
})
export class TambahProdukComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
