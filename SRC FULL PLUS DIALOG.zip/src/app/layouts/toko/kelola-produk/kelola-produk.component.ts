import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kelola-produk',
  templateUrl: './kelola-produk.component.html',
  styleUrls: ['./kelola-produk.component.scss']
})
export class KelolaProdukComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
