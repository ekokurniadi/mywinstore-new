import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-toko',
  templateUrl: './header-toko.component.html',
  styleUrls: ['./header-toko.component.scss']
})
export class HeaderTokoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
