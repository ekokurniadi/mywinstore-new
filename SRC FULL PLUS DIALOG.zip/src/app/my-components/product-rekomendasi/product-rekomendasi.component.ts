import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-rekomendasi',
  templateUrl: './product-rekomendasi.component.html',
  styleUrls: ['./product-rekomendasi.component.scss']
})
export class ProductRekomendasiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
