import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daftar-pesanan-content',
  templateUrl: './daftar-pesanan-content.component.html',
  styleUrls: ['./daftar-pesanan-content.component.scss']
})
export class DaftarPesananContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
