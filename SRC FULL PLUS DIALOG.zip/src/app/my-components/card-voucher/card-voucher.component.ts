import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-voucher',
  templateUrl: './card-voucher.component.html',
  styleUrls: ['./card-voucher.component.scss']
})
export class CardVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
